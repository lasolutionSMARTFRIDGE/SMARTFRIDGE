package org.sintef.jarduino;

/**
 * Created with IntelliJ IDEA.
 * User: duke
 * Date: 18/04/13
 * Time: 16:31
 */
public enum JArduinoCom {

    Ethernet, Serial, AndroidBluetooth;

}
